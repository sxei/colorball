﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Windows.Forms;
using System.Security.Cryptography;

namespace 彩色连珠
{
    class SaveScore
    {
        public SaveScore()
        { }
        public const string scoreFile = "score.dat";
        /// <summary>
        /// 保存成绩
        /// </summary>
        /// <param name="name">姓名</param>
        /// <param name="score">成绩</param>
        public static void saveScore(string name, int score)
        {
            string file = Application.StartupPath + "\\" + scoreFile;
            if (!File.Exists(file))
                File.CreateText(file);
            StreamReader sr = new StreamReader(file);
            List<string> names = new List<string> { };
            List<int> scores = new List<int> { };
            string temp = "";
            try
            {
                while ((temp = sr.ReadLine()) != null)
                {
                    temp = SimplyDecrypt(temp);
                    names.Add(temp.Split(':')[0]);
                    scores.Add(Convert.ToInt32(temp.Split(':')[1]));
                }
            }
            catch { }
            sr.Close();
            int max = score;//假设传过来的score是最高分
            int i = 0;
            for (; i < scores.Count; i++)
                if (scores[i] < max)//一旦发现有比max小的数，跳出循环
                    break;
            scores.Insert(i, score);//在指定位置插入成绩和姓名
            names.Insert(i, name);
            StreamWriter sw = new StreamWriter(file);
            for (int j = 0; j < names.Count; j++)
                sw.WriteLine(SimplyEncrypt(names[j] + ":" + scores[j]));//写入文件
            sw.Close();
        }
        public static int redMax()//读取最高分
        {
            int max = 0;
            try
            {
                string file = Application.StartupPath + "\\" + scoreFile;
                if (File.Exists(file))
                {
                    StreamReader sr = new StreamReader(file);
                    max =Convert.ToInt32(SimplyDecrypt(sr.ReadLine()).Split(':')[1]);
                    sr.Close();
                }
            }
            catch { }
            return max;
        }
        public static string readScore()//读取所有成绩
        {
            string result = "成绩排行榜如下：\n";
            try
            {
                string file = Application.StartupPath + "\\" + scoreFile;
                if (File.Exists(file))
                {
                    string temp = "";
                    StreamReader sr = new StreamReader(file);
                    int i = 1;
                    while ((temp = sr.ReadLine()) != null)
                    {
                        temp = SimplyDecrypt(temp);
                        result += "第" + i + "名：" + temp.Split(':')[0] + "，成绩：" + temp.Split(':')[1] + "\n";
                        i++;
                    }
                    sr.Close();
                }
            }
            catch{ }
            return result;
        }
        private const string Secret = "timizhuo"; // Secret的长度必须为8位！！
        private const string IV = "liuxianan";  // IV的长度必须在8位以上！

        private static string SimplyEncrypt(string rawContent)//加密
        {
            try
            {
                var des = new DESCryptoServiceProvider();
                var encryptor = des.CreateEncryptor(Encoding.ASCII.GetBytes(Secret), Encoding.ASCII.GetBytes(IV));
                var dataToEnc = Encoding.UTF8.GetBytes(rawContent);
                var resultStr = encryptor.TransformFinalBlock(dataToEnc, 0, dataToEnc.Length);
                return Convert.ToBase64String(resultStr);
            }
            catch { return ""; }
        }

        private static string SimplyDecrypt(string encryptedContent)//解密
        {
            try
            {
                var result = string.Empty;
                var des = new DESCryptoServiceProvider();
                var decryptor = des.CreateDecryptor(Encoding.ASCII.GetBytes(Secret), Encoding.ASCII.GetBytes(IV));
                var dataToDec = Convert.FromBase64String(encryptedContent);
                var resultBytes = decryptor.TransformFinalBlock(dataToDec, 0, dataToDec.Length);
                result = Encoding.UTF8.GetString(resultBytes);
                return result;
            }
            catch { return ""; }
        }
    }
}
