﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace 彩色连珠
{
    public partial class Form保存成绩 : Form
    {
        public int score;
        Form主窗口 f;
        public Form保存成绩(int score,Form主窗口 f)
        {
            InitializeComponent();
            this.score = score;
            this.f = f;
        }

        private void Form保存成绩_Load(object sender, EventArgs e)
        {
            label成绩.Text = "您的成绩为："+score+"分";
        }

        private void button放弃_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button留名_Click(object sender, EventArgs e)
        {
            SaveScore.saveScore(textBox姓名.Text,score);//保存成绩到文件
            f.readMaxScore();//读取最高分
            this.Close();
        }
        
    }
}
